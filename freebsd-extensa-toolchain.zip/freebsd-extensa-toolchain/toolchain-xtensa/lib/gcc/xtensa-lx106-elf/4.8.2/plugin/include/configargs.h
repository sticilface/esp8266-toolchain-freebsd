/* Generated automatically. */
static const char configuration_arguments[] = "/opt/Espressif/crosstool-NG/.build/src/gcc-4.8.2/configure --build=x86_64-build_unknown-freebsd9.2 --host=x86_64-build_unknown-freebsd9.2 --target=xtensa-lx106-elf --prefix=/opt/Espressif/crosstool-NG/builds/xtensa-lx106-elf --with-local-prefix=/opt/Espressif/crosstool-NG/builds/xtensa-lx106-elf/xtensa-lx106-elf/sysroot --disable-libmudflap --with-sysroot=/opt/Espressif/crosstool-NG/builds/xtensa-lx106-elf/xtensa-lx106-elf/sysroot --with-newlib --enable-threads=no --disable-shared --with-pkgversion='crosstool-NG 1.20.0' --disable-__cxa_atexit --with-gmp=/opt/Espressif/crosstool-NG/.build/xtensa-lx106-elf/buildtools --with-mpfr=/opt/Espressif/crosstool-NG/.build/xtensa-lx106-elf/buildtools --with-mpc=/opt/Espressif/crosstool-NG/.build/xtensa-lx106-elf/buildtools --with-isl=/opt/Espressif/crosstool-NG/.build/xtensa-lx106-elf/buildtools --with-cloog=/opt/Espressif/crosstool-NG/.build/xtensa-lx106-elf/buildtools --with-libelf=/opt/Espressif/crosstool-NG/.build/xtensa-lx106-elf/buildtools --enable-lto --enable-target-optspace --disable-libgomp --disable-libmudflap --disable-nls --disable-multilib --enable-languages=c,c++";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { NULL, NULL} };
